/*
|--------------------------------------------------------------------------------------------------
| Programmers Name: Anthony Kish
| Course:           CS-212
| Program  Name:    Binary Trees
| Date:             4/28/2024
|
|--------------------------------------------------------------------------------------------------
| Program Description:
|   Takes an input file and creates a binary tree. Will run various processes to calculate different things
|	and output them to seperate files
|
|--------------------------------------------------------------------------------------------------
| Inputs:
|   Numbers.txt
|  
|--------------------------------------------------------------------------------------------------
| Processing:
|   Uses Pre Order, In Order, and Post Order traverses to run calculations on a binary tree
|  
|--------------------------------------------------------------------------------------------------
| Outputs:
|   PreOrderOutput.txt, InOrderOutput.txt, PostOrderOutpput.txt
|
|--------------------------------------------------------------------------------------------------
*/

#include "KishA_Lab8.h"

int main(void)
{
	FILE* pFin = NULL;
	FILE* pPreOrderOut = NULL;
	FILE* pInOrderOut = NULL;
	FILE* pPostOrderOut = NULL;
	
	node* pRoot = NULL;
	
	
	int min = 0;
	int max = 0;
	
	OpenFiles(&pFin, &pPreOrderOut, &pInOrderOut, &pPostOrderOut);
	
	PrintHeader(stdout);
	PrintHeader(pPreOrderOut);
	PrintHeader(pInOrderOut);
	PrintHeader(pPostOrderOut);
	
	ReadDataInFromFile(pFin, &pRoot);
	
	// Printing pre order to output
	PrintDivider(pPreOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pPreOrderOut, "Binary Search Tree Pre Order, Before Deletion", SCREEN_WIDTH);
	PrintDivider(pPreOrderOut, DASH, SCREEN_WIDTH);

	PrintPreOrder(pPreOrderOut, pRoot);
	
	// Printing in order to output
	PrintDivider(pInOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pInOrderOut, "Binary Search Tree In Order, Before Deletion", SCREEN_WIDTH);
	PrintDivider(pInOrderOut, DASH, SCREEN_WIDTH);

	PrintInOrder(pInOrderOut, pRoot);
	
	// Printing post order to output
	PrintDivider(pPostOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pPostOrderOut, "Binary Search Tree Post Order, Before Deletion", SCREEN_WIDTH);
	PrintDivider(pPostOrderOut, DASH, SCREEN_WIDTH);

	PrintPostOrder(pPostOrderOut, pRoot);
	
	// Finding min, max, and average
	FindMinValuePreOrder(&min, pRoot);
	FindMaxValueInOrder(&max, pRoot);
	
	//Printing results
	PrintMinValue("Minimum Value For Pre Order Binary Search Tree", min, pPreOrderOut);
	PrintMaxValue("Maximum Value For In Order Binary Search Tree", max, pInOrderOut);
	PrintAverageValue("Average Value For Post Order Binary Search Tree", pRoot, pPostOrderOut);
	
	// Deleting nodes
	DeleteNode(&pRoot, min);
	DeleteNode(&pRoot, max);
	DeleteNode(&pRoot, 5);
	DeleteNode(&pRoot, 15);
	DeleteNode(&pRoot, 28);
	DeleteNode(&pRoot, 48);
	DeleteNode(&pRoot, 37);
	DeleteNode(&pRoot, 31);
	
	// Printing pre order to output
	PrintDivider(pPreOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pPreOrderOut, "Binary Search Tree Pre Order, After Deletion", SCREEN_WIDTH);
	PrintDivider(pPreOrderOut, DASH, SCREEN_WIDTH);

	PrintPreOrder(pPreOrderOut, pRoot);
	
	// Printing in order to output
	PrintDivider(pInOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pInOrderOut, "Binary Search Tree In Order, After Deletion", SCREEN_WIDTH);
	PrintDivider(pInOrderOut, DASH, SCREEN_WIDTH);

	PrintInOrder(pInOrderOut, pRoot);
	
	// Printing post order to output
	PrintDivider(pPostOrderOut, DASH, SCREEN_WIDTH);
	CenterString(pPostOrderOut, "Binary Search Tree Post Order, After Deletion", SCREEN_WIDTH);
	PrintDivider(pPostOrderOut, DASH, SCREEN_WIDTH);

	PrintPostOrder(pPostOrderOut, pRoot);
	
	// Finding min, max, and average
	min = 0;
	max = 0;

	
	FindMinValuePreOrder(&min, pRoot);
	FindMaxValueInOrder(&max, pRoot);
	
	//Printing results
	PrintMinValue("New Minimum Value For Pre Order Binary Search Tree", min, pPreOrderOut);
	PrintMaxValue("New Maximum Value For In Order Binary Search Tree", max, pInOrderOut);
	PrintAverageValue("New Average Value For Post Order Binary Search Tree", pRoot, pPostOrderOut);

	FreeNodes(&pRoot);
	
	if(pRoot == NULL)
	{
		fprintf(stdout, "\n\nList is Free!\n");
	}
	
	CloseFiles(&pFin, &pPreOrderOut, &pInOrderOut, &pPostOrderOut);
	
	
	
}