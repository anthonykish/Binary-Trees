#ifndef KISHA_LAB8_H
#define KISHA_LAB8_H

// Include statements
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Constants / Macros
#define SCREEN_WIDTH 80
#define STAR '*'
#define DASH '-'

#define SCHOOL "Binghamton University"
#define PROGRAMMER "Program written by: Anthony Kish"
#define LAB "Binary Trees"



// Structures

typedef struct
{
	int number;

} recordType;

typedef struct nodeType
{
	recordType record;

	struct nodeType* pLeft;
	struct nodeType* pRight;

} node;

// Prototypes
void PrintHeader(FILE* pOutput);
void PrintDivider(FILE* pOutput, char symbol, int numberOf);
void CenterString(FILE* pOutput, const char string[], int lengthToCenterAcross);
void OpenFiles(FILE** pFin, FILE** pFoutPre, FILE** pFoutIn, FILE** pFoutPost);
void CloseFiles(FILE** pFin, FILE** pFoutPre, FILE** pFoutIn, FILE** pFoutPost);
void ReadDataInFromFile(FILE* pFin, node** pRoot);
void CreateNode(node* pNewNode, int newNumber);
_Bool IsTreeEmpty(node* pRoot);
void InsertNode(node** pRoot, node** pNewNode);
void PrintPreOrder(FILE* pFout, node* pCurrentNode);
void PrintInOrder(FILE* pFout, node* pCurrentNode);
void PrintPostOrder(FILE* pFout, node* pCurrentNode);
void FindMinValuePreOrder(int* min, node* pCurrentNode);
void FindMaxValueInOrder(int* max, node* pCurrentNode);
void FindAverageValuePostOrder(int* average, node* pCurrentNode, int* numberOfNodes);
void PrintMinValue(char header[], int min, FILE* pFout);
void PrintMaxValue(char header[], int max, FILE* pFout);
void PrintAverageValue(char header[], node* pCurrentNode, FILE* pFout);
_Bool SearchTree(int number, node* pRoot, node** pCurrent, node** pParent);
void DeleteLeafNode(node** pRoot, node** pCurrent, node** pParent);
void DeleteNodeWithLeftChildOnly(node** pRoot, node** pCurrent, node** pParent);
void DeleteNodeWithRightChildOnly(node** pRoot, node** pCurrent, node** pParent);
void DeleteNodeWithTwoChildren(node** pRoot, node** pCurrent, node** pParent);
void DeleteNode(node** pRoot, int value);
void FreeNodes(node** pRoot);



#endif