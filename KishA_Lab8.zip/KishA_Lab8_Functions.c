#include "KishA_Lab8.h"

//-----------------------------------------------------------------------------
// Function Name: PrintHeader
// Description:
//   This function will call the functions needed to print a header to the 
//  screen. 
//
//-----------------------------------------------------------------------------
void PrintHeader(FILE* pOutput)
{
	// Call function to print a divider to the screen
	PrintDivider(pOutput, STAR, SCREEN_WIDTH);

	// Call functions to print three strings to center to the screen
	CenterString(pOutput, SCHOOL, SCREEN_WIDTH);
	CenterString(pOutput, PROGRAMMER, SCREEN_WIDTH);
	CenterString(pOutput, LAB, SCREEN_WIDTH);

	// Call function to print a divider to the screen
	PrintDivider(pOutput, STAR, SCREEN_WIDTH);
}


//-----------------------------------------------------------------------------
// Function Name: PrintDivider
// Description:
//   Symbols will be printed to the screen. 
//
//-----------------------------------------------------------------------------
void PrintDivider(FILE* pOutput, char symbol, int numberOf)
{
	// Initialize LCV (Loop Control Variable) to 0
	int counter = 0;

	// Print a bunch of symbols across the screen
	while (counter < numberOf)
	{
		// Print one character to the screen
		fprintf(pOutput, "%c", symbol);

		// Increment counter
		counter++;
	}

	// Move the cursor down to the next line
	fprintf(pOutput, "\n");
}


//-----------------------------------------------------------------------------
// Function Name: CenterString
// Description:
//   The array of characters passed into the function will be centered
//  across the screen using the following formula:
//  
//    (lengthToCenterAcross + the string length) / 2
//
//-----------------------------------------------------------------------------
void CenterString(FILE* pOutput, const char string[], int lengthToCenterAcross)
{
	// Capture how long the string is
	// Cast to an integer because strlen technically returns size_t
	int stringLength = (int)strlen(string);

	// Calculate the width to print the string in
	int width = (lengthToCenterAcross + stringLength) / 2;

	// Calculate how many blank spaces are needed before printing the string
	int numberOfBlankSpaces = width - stringLength;

	// Initialize LCV (Loop Control Variable) to 0
	int counter = 0;

	// Print the spaces needed to center the string
	while (counter < numberOfBlankSpaces)
	{
		// Print one space
		fprintf(pOutput, " ");

		// Increment counter
		counter++;
	}

	// Print the string
	fprintf(pOutput, "%s\n", string);
}


//-----------------------------------------------------------------------------
// Function Name: OpenFiles
// Description:
//   All data files are opened.
//
//-----------------------------------------------------------------------------
void OpenFiles(FILE** pFin, FILE** pFoutPre, FILE** pFoutIn, FILE** pFoutPost)
{
	// Open files
	*pFin = fopen("Numbers.txt", "r");
	*pFoutPre = fopen("PreOutput.txt", "w");
	*pFoutIn = fopen("InOutput.txt", "w");
	*pFoutPost = fopen("PostOutput.txt", "w");
}


//-----------------------------------------------------------------------------
// Function Name: CloseFiles
// Description:
//   All data files are closed
//
//-----------------------------------------------------------------------------
void CloseFiles(FILE** pFin, FILE** pFoutPre, FILE** pFoutIn, FILE** pFoutPost)
{
	// Check to see if the input file pointer is valid
	if (*pFin != NULL)
	{
		// Close the input file
		fclose(*pFin);
	}

	// Check to see if the output file pointer is valid
	if (*pFoutPre != NULL)
	{
		// Close the output file
		fclose(*pFoutPre);
	}

	// Check to see if the output file pointer is valid
	if (*pFoutIn != NULL)
	{
		// Close the output file
		fclose(*pFoutIn);
	}

	// Check to see if the output file pointer is valid
	if (*pFoutPost != NULL)
	{
		// Close the output file
		fclose(*pFoutPost);
	}
}

//-----------------------------------------------------------------------------
// Function Name: ReadDataInFromFile
// Description:
//   Data will be read in from an input file and will be stored in a binary 
//  tree. 
//
//-----------------------------------------------------------------------------
void ReadDataInFromFile(FILE* pFin, node** pRoot)
{
	int newNumber;
	node* pNewNode;

	if (pFin == NULL)

	{
		// Print message to the screen
		printf("No file has opened\n");
	}
	else
	{
		while (!feof(pFin))
		{
			fscanf(pFin, "%d", &newNumber);

			pNewNode = (node*)malloc(sizeof(node));
			
			CreateNode(pNewNode, newNumber);
			
			InsertNode(pRoot, &pNewNode);
		}
	}
}

//-----------------------------------------------------------------------------
// Function Name: CreateNode
// Description:
//  Members of a new node will be initialized
//
//-----------------------------------------------------------------------------
void CreateNode(node* pNewNode, int newNumber)
{
	// Assign new data to the new node
	pNewNode->record.number = newNumber;

	// Set new pointers to NULL
	pNewNode->pLeft = NULL;
	pNewNode->pRight = NULL;
}


//-----------------------------------------------------------------------------
// Function Name: IsTreeEmpty
// Description:
//   This function will return true if a tree is empty and false if it is not.
//
//-----------------------------------------------------------------------------
_Bool IsTreeEmpty(node* pRoot)
{
	if(pRoot == NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//-----------------------------------------------------------------------------
// Function Name: InsertNode
// Description:
//   A new node will be inserted into the tree following the criteria of a 
//  Binary Search Tree (BST)
//
//-----------------------------------------------------------------------------
void InsertNode(node** pRoot, node** pNewNode)
{
	node* pParent;
	node* pCurrent;


	// Check to see if the root is NULL
	if (IsTreeEmpty(*pRoot))
	{
		// Assign the first node of our tree
		*pRoot = *pNewNode;
	}
	else
	{
		// Start searching at the root node
		pParent = NULL;
		pCurrent = *pRoot;

		while (pCurrent != NULL)
		{
			if ((*pNewNode)->record.number <= pCurrent->record.number)
			{
				// Update pParent and pCurrent pointers
				pParent = pCurrent;
				pCurrent = pCurrent->pLeft;
			}
			else
			{
				// Update pParent and pCurrent pointers
				pParent = pCurrent;
				pCurrent = pCurrent->pRight;
			}
		}

		if ((*pNewNode)->record.number <= pParent->record.number)
		{
			// Assign new node to the tree
			pParent->pLeft = *pNewNode;
		}
		else
		{
			// Assign new node to the tree
			pParent->pRight = *pNewNode;
		}

	}
}

//-----------------------------------------------------------------------------
// Function Name: PrintPreOrder
// Description:
//   Print the tree using Pre Order Traverse 
//
//-----------------------------------------------------------------------------
void PrintPreOrder(FILE* pFout, node* pCurrentNode)
{
	if (pCurrentNode != NULL)
	{
		fprintf(pFout, "%d\n", pCurrentNode->record.number);
		PrintPreOrder(pFout, pCurrentNode->pLeft);
		PrintPreOrder(pFout, pCurrentNode->pRight);
	}
}


//-----------------------------------------------------------------------------
// Function Name: PrintInOrder
// Description:
//   Print the tree using In Order Traverse 
//
//-----------------------------------------------------------------------------
void PrintInOrder(FILE* pFout, node* pCurrentNode)
{
	if (pCurrentNode != NULL)
	{
		PrintInOrder(pFout, pCurrentNode->pLeft);
		fprintf(pFout, "%d\n", pCurrentNode->record.number);
		PrintInOrder(pFout, pCurrentNode->pRight);
	}
}

//-----------------------------------------------------------------------------
// Function Name: PrintPostOrder
// Description:
//	Prints the tree using In Order Traverse
//
//-----------------------------------------------------------------------------
void PrintPostOrder(FILE* pFout, node* pCurrentNode)
{
	if(pCurrentNode != NULL)
	{
		PrintPostOrder(pFout, pCurrentNode->pLeft);
		PrintPostOrder(pFout, pCurrentNode->pRight);
		fprintf(pFout, "%d\n", pCurrentNode->record.number);
	}
}

//-----------------------------------------------------------------------------
// Function Name: FindMinValuePreOrder
// Description:
//	Finds the minimum value of a binary tree
//
//-----------------------------------------------------------------------------
void FindMinValuePreOrder(int* min, node* pCurrentNode)
{
	if(*min == 0)
	{
		*min = pCurrentNode->record.number;
	}
	
	if(pCurrentNode != NULL)
	{
		if(pCurrentNode->record.number < *min)
		{
			*min = pCurrentNode->record.number;
		}
		
		FindMinValuePreOrder(min, pCurrentNode->pLeft);
		FindMinValuePreOrder(min, pCurrentNode->pRight);
	}
}

//-----------------------------------------------------------------------------
// Function Name: FindMaxValueInOrder
// Description:
//	Finds the maximum value of a binary tree
//
//-----------------------------------------------------------------------------
void FindMaxValueInOrder(int* max, node* pCurrentNode)
{
	if(pCurrentNode != NULL)
	{
		FindMinValuePreOrder(max, pCurrentNode->pLeft);
		
		if(*max < pCurrentNode->record.number)
		{
			*max = pCurrentNode->record.number;
		}
		
		FindMinValuePreOrder(max, pCurrentNode->pRight);
	}
}
//-----------------------------------------------------------------------------
// Function Name: FindAverageValuePostOrder
// Description:
//	Calculates the sum of all nodes in a binary tree, as well as track how many nodes are in said tree
//
//-----------------------------------------------------------------------------
void FindAverageValuePostOrder(int* average, node* pCurrentNode, int* numberOfNodes)
{	
	if(pCurrentNode != NULL)
	{
		FindAverageValuePostOrder(average, pCurrentNode->pLeft, numberOfNodes);
		
		FindAverageValuePostOrder(average, pCurrentNode->pRight, numberOfNodes);
	
		*average = pCurrentNode->record.number + *average;
		(*numberOfNodes)++;
	}
		
}

//-----------------------------------------------------------------------------
// Function Name: PrintMinValue
// Description:
//	Prints the minimum value of a binary tree onto a specific output file
//
//-----------------------------------------------------------------------------
void PrintMinValue(char header[], int min, FILE* pFout)
{
	PrintDivider(pFout, DASH, SCREEN_WIDTH);
	CenterString(pFout, header, SCREEN_WIDTH);
	PrintDivider(pFout, DASH, SCREEN_WIDTH);

	fprintf(pFout, "Minimum: %d\n", min);
}

//-----------------------------------------------------------------------------
// Function Name: PrintMaxValue
// Description:
//	Prints the max value of a binary tree onto a specific file
//
//-----------------------------------------------------------------------------
void PrintMaxValue(char header[], int max, FILE* pFout)
{
	PrintDivider(pFout, DASH, SCREEN_WIDTH);
	CenterString(pFout, header, SCREEN_WIDTH);
	PrintDivider(pFout, DASH, SCREEN_WIDTH);

	fprintf(pFout, "Maximum: %d\n", max);
}

//-----------------------------------------------------------------------------
// Function Name: PrintAverageValue
// Description:
//	Calls the FindAverageValuePostOrder function and calculates the average of a binary tree.
//	Also prints the average onto a output file
//
//-----------------------------------------------------------------------------
void PrintAverageValue(char header[], node* pCurrentNode, FILE* pFout)
{
	int sum = 0;
	int numOfNodes = 0;
	double average = 0;
	
	FindAverageValuePostOrder(&sum, pCurrentNode, &numOfNodes);
	
	PrintDivider(pFout, DASH, SCREEN_WIDTH);
	CenterString(pFout, header, SCREEN_WIDTH);
	PrintDivider(pFout, DASH, SCREEN_WIDTH);

	if(numOfNodes != 0)
	{
		average = (double) sum / (double) numOfNodes;
		
		fprintf(pFout, "Average: %2.2f \n\n", average);
	}
	// divide by zero check
	else
	{
		fprintf(pFout, "ERROR: CANNOT DIVIDE BY ZERO\n");
	}
}

//-----------------------------------------------------------------------------
// Function Name: SearchTree
// Description:
//	Searches the binary tree for a node with a specific number given by the user
//	Also helps instantiate the parent and current node pointers
//
//-----------------------------------------------------------------------------
_Bool SearchTree(int number, node* pRoot, node** pCurrent, node** pParent)
{
	_Bool returnValue = 0;
	
	if(pRoot == NULL)
	{
		*pCurrent = NULL;
		*pParent = NULL;
	}
	else
	{
		*pCurrent = pRoot;
		
		*pParent = NULL;
	}
	
	while(*pCurrent != NULL && returnValue != 1)
	{
		if((*pCurrent)->record.number == number)
		{
			returnValue = 1;
		}
		else if(number < (*pCurrent)->record.number)
		{
			*pParent = *pCurrent;
			
			*pCurrent = (*pCurrent)->pLeft;
		}
		else
		{
			*pParent = *pCurrent;
			
			*pCurrent = (*pCurrent)->pRight;
		}
	}
	
	return returnValue;
}

//-----------------------------------------------------------------------------
// Function Name: DeleteLeafNode
// Description:
//   Deletes a node with no children
//
//-----------------------------------------------------------------------------
void DeleteLeafNode(node** pRoot, node** pCurrent, node** pParent)
{
	if(*pParent == NULL)
	{
		*pRoot = NULL;
		
		free(*pCurrent);
	}
	else if((*pParent)->pLeft == *pCurrent)
	{
		(*pParent)->pLeft = NULL;
		
		free(*pCurrent);
	}
	else
	{
		(*pParent)->pRight = NULL;
		
		free(*pCurrent);
	}
}

//-----------------------------------------------------------------------------
// Function Name: DeleteNodeWitLeftChildOnly
// Description:
//   Deletes a node with only one child branching left
//
//-----------------------------------------------------------------------------
void DeleteNodeWithLeftChildOnly(node** pRoot, node** pCurrent, node** pParent)
{
	if(*pParent != NULL)
	{
		if((*pCurrent) == (*pParent)->pRight)
		{
			(*pParent)->pRight = (*pCurrent)->pLeft;
			
			free(*pCurrent);
		}
		else
		{
			(*pParent)->pLeft = (*pCurrent)->pLeft;
			
			free(*pCurrent);
		}
	}
	else
	{
		*pRoot = (*pRoot)->pLeft;
		
		free(*pCurrent);
	}
}

//-----------------------------------------------------------------------------
// Function Name: DeleteNodeWithRightChildOnly
// Description:
//   Deletes a node with only one child branching right
//
//-----------------------------------------------------------------------------
void DeleteNodeWithRightChildOnly(node** pRoot, node** pCurrent, node** pParent)
{
	if((*pParent) != NULL)
	{
		if(*pCurrent == (*pParent)->pRight)
		{
			(*pParent)->pRight = (*pCurrent)->pRight;
			
			free(*pCurrent);
		}
		else
		{
			(*pParent)->pLeft = (*pCurrent)->pRight;
			
			free(*pCurrent);
		}
	}
	else
	{
		*pRoot = (*pRoot)->pRight;
		
		free(*pCurrent);
	}
}


//-----------------------------------------------------------------------------
// Function Name: DeleteNodeWithTwoChildren
// Description:
//   Deletes a node with two children 
//
//-----------------------------------------------------------------------------
void DeleteNodeWithTwoChildren(node** pRoot, node** pCurrent, node** pParent)
{
	node* pTemp;
	
	*pParent = *pCurrent;
	
	pTemp = (*pCurrent)->pLeft;
	
	while(pTemp->pRight != NULL)
	{
		*pParent = pTemp;
		
		pTemp = pTemp->pRight;
	}
	
	if(*pParent == *pCurrent)
	{
		(*pParent)->pLeft = pTemp->pLeft;
	}
	else
	{
		(*pParent)->pRight = pTemp->pLeft;
	}
	
	(*pCurrent)->record.number = pTemp->record.number;
	
	free(pTemp);
}

//-----------------------------------------------------------------------------
// Function Name: DeleteNode
// Description:
//   Takes a value and deletes the node with that value. Checks if the node has a child
//
//-----------------------------------------------------------------------------
void DeleteNode(node** pRoot, int value)
{
	node* pCurrent = NULL;
	node* pParent = NULL;
	
	// checks to see if the value is in the tree
	if(SearchTree(value, *pRoot, &pCurrent, &pParent) == 1)
	{
		// checks if value is a leaf node
		if(pCurrent->pLeft == NULL && pCurrent->pRight == NULL)
		{
			DeleteLeafNode(pRoot, &pCurrent, &pParent);
		}
		
		// checks if current node has a left child only
		else if(pCurrent->pLeft != NULL && pCurrent->pRight == NULL)
		{
			DeleteNodeWithLeftChildOnly(pRoot, &pCurrent, &pParent);
		}
		
		// checks if the current node has only a right child
		else if(pCurrent->pLeft == NULL && pCurrent->pRight != NULL)
		{
			DeleteNodeWithRightChildOnly(pRoot, &pCurrent, &pParent);
		}
		
		// checks if the current node has both left and right children
		else if(pCurrent->pLeft != NULL && pCurrent->pRight != NULL)
		{
			DeleteNodeWithTwoChildren(pRoot, &pCurrent, &pParent);
		}
	}
	
}

//-----------------------------------------------------------------------------
// Function Name: FreeNodes
// Description:
//    This function will not work until you write all the functions that are 
//  defined in the Playbook Notes - How to delete a node
//
//-----------------------------------------------------------------------------


void FreeNodes(node** pRoot)
{
	while (!IsTreeEmpty(*pRoot))
	{
		DeleteNode(pRoot, (*pRoot)->record.number);
	}

}
